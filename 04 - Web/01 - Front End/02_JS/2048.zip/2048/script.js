//Taille de la grid
const taille = 5;

//Recup toutes les cases du jeu
var cases = document.getElementsByClassName("case");
var grille = document.getElementById("grid");

var lignes = [];

gridSettings();

// au chargement de la page on définit la taille de la grille en css.
function gridSettings() {
    let stringGrid = "";
    for (let i = 0; i < taille; i++) {
        stringGrid += "2fr ";
        let ligne = [];
        for (let j = 0; j < taille; j++) {
            let caseTab = document.createElement("div");
            caseTab.classList.add("case");
            grille.appendChild(caseTab);
            ligne.push(caseTab);
        }
        lignes.push(ligne);
    }
    grille.style.gridTemplateColumns = stringGrid;

    let coordCase1 = [];
    let coordCase2 = [];

    console.log(setRandomCase());

    for (let k = 0; k < 2; k++) {
        if(setRandomCase() != coordCase1)
        {
            
        }
    }
}

function setRandomCase() {
    let tab = [];
    for (let i = 0; i < 2; i++) {
        var unRand = Math.floor(Math.random() * (taille - 1 - 0 + 1)) + 0;
        tab.push(unRand);
    }
    return tab;
}



// On check si la partie est terminée ou un coup est jouable.

function Result() {
    var cpt = 0;
    do {
        cpt++;
    } while (cases[cpt] != "");

    if (FlagCombinaison && cpt < cases.lenght - 1) {
        alert("Partie Terminée !");
    }
}