Fonction : 

AjouteCase() => Ajoute une case dans une case vide dans le tableau. 

DeplaceCase() => Pour tous les chiffres il faut le déplacer que si la case est vide ou est identique au chiffre
On s'arrete que quand il n'y a plus de case vide ou de case identique. 

UpdateScore() => Qui va changer les données au dessus du jeu.  

Result() => Si aucune case Blanche et Aucune combinaison faite => GAME OVER.

CreationGrille => Mise en place de la DOM


NB : 
mise en place d'un cookie qui garde en mémoire le score. SI POSSIBLE.

