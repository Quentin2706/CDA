<div class="demiPage colonne">
    <form action="index.php?page=actionConnection" method="post">
        <div>
            <label for="pseudo">Pseudo</label>
            <input type="text" name="pseudo" required />
        </div>
        <div>
            <label for="motDePasse">mot De Passe</label>
            <input type="password" name="motDePasse" required />
        </div>
        <div>
            <div></div>
            <button type="submit">Valider</button>
            <div></div>
        </div>

    </form>
    <div>
        <div></div>

        <a href="index.php?page=inscription">s'inscrire</a>
        <div></div>
    </div>
</div>