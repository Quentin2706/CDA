<div class="demiPage">
<h2><?php echo texte("accueil")?></h2>
</div>